#ifndef CC1101_HAL_H
#define CC1101_HAL_H

#include <stdint.h>
#include <msp430.h>

/*
 * Hardware Abstraction Layer for CC1101 <-> MSP430FR2476.
 *
 * You MUST edit the pin definitions below if your wiring differs.
 */

/* ===== CC1101 CSn ON UCA0STE (P4.7) ===== */
#define CC1101_CSN_PORT_DIR   P4DIR
#define CC1101_CSN_PORT_OUT   P4OUT
#define CC1101_CSN_PIN        BIT7

/* GDO0 (optional, for packet sync / end-of-packet signalling) */
#define CC1101_GDO0_PORT_DIR  P1DIR
#define CC1101_GDO0_PORT_IN   P1IN
#define CC1101_GDO0_PORT_OUT  P1OUT
#define CC1101_GDO0_PORT_REN  P1REN
#define CC1101_GDO0_PIN       BIT2

/* ================= SPI PIN MAPPING FOR MSP430FR2476 (UCA0 on P5.x) ================= */

/* SIMO (Master Out, CC1101 SI) — UCA0SIMO on P5.2 */
#define CC1101_SPI_MOSI_DIR   P5DIR
#define CC1101_SPI_MOSI_SEL0  P5SEL0
#define CC1101_SPI_MOSI_SEL1  P5SEL1
#define CC1101_SPI_MOSI_PIN   BIT2

/* SOMI (Master In, CC1101 SO) — UCA0SOMI on P5.1 */
#define CC1101_SPI_MISO_DIR   P5DIR
#define CC1101_SPI_MISO_SEL0  P5SEL0
#define CC1101_SPI_MISO_SEL1  P5SEL1
#define CC1101_SPI_MISO_PIN   BIT1

/* SCLK — UCA0CLK on P5.0 */
#define CC1101_SPI_SCLK_DIR   P5DIR
#define CC1101_SPI_SCLK_SEL0  P5SEL0
#define CC1101_SPI_SCLK_SEL1  P5SEL1
#define CC1101_SPI_SCLK_PIN   BIT0

/* MISO input register for ready polling */
#define CC1101_SPI_MISO_PORT_IN  P5IN

/* Clock frequency used for delay calculations (Hz) */
#ifndef SMCLK_FREQUENCY_HZ
#define SMCLK_FREQUENCY_HZ 8000000UL
#endif

#ifdef __cplusplus
extern "C" {
#endif

void cc1101_hal_init(void);
void cc1101_hal_spi_init(void);
uint8_t cc1101_hal_spi_tx_rx(uint8_t data);

void cc1101_hal_csn_low(void);
void cc1101_hal_csn_high(void);

/* Optional delay helpers */
void cc1101_hal_delay_cycles(uint32_t cycles);
void cc1101_hal_delay_ms(uint16_t ms);

#ifdef __cplusplus
}
#endif

#endif /* CC1101_HAL_H */
