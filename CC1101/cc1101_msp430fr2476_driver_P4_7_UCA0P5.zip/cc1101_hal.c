#include "cc1101_hal.h"

/*
 * Basic blocking HAL implementation using eUSCI_A0 in 3-pin SPI master mode.
 */

void cc1101_hal_delay_cycles(uint32_t cycles)
{
    while (cycles--) {
        __no_operation();
    }
}

void cc1101_hal_delay_ms(uint16_t ms)
{
    /* crude delay based on SMCLK frequency; not low-power */
    uint32_t cycles = (SMCLK_FREQUENCY_HZ / 1000UL) * (uint32_t)ms;
    cc1101_hal_delay_cycles(cycles);
}

void cc1101_hal_csn_low(void)
{
    CC1101_CSN_PORT_OUT &= ~CC1101_CSN_PIN;
}

void cc1101_hal_csn_high(void)
{
    CC1101_CSN_PORT_OUT |= CC1101_CSN_PIN;
}

void cc1101_hal_spi_init(void)
{
    /* Configure SPI pins directions */
    CC1101_SPI_MOSI_DIR |= CC1101_SPI_MOSI_PIN;
    CC1101_SPI_MISO_DIR &= ~CC1101_SPI_MISO_PIN;
    CC1101_SPI_SCLK_DIR |= CC1101_SPI_SCLK_PIN;

    /* Select SPI function for P5.0, P5.1, P5.2 */
    CC1101_SPI_MOSI_SEL0 |= CC1101_SPI_MOSI_PIN;
    CC1101_SPI_MOSI_SEL1 &= ~CC1101_SPI_MOSI_PIN;

    CC1101_SPI_MISO_SEL0 |= CC1101_SPI_MISO_PIN;
    CC1101_SPI_MISO_SEL1 &= ~CC1101_SPI_MISO_PIN;

    CC1101_SPI_SCLK_SEL0 |= CC1101_SPI_SCLK_PIN;
    CC1101_SPI_SCLK_SEL1 &= ~CC1101_SPI_SCLK_PIN;

    /* Hold eUSCI_A0 in reset */
    UCA0CTLW0 |= UCSWRST;

    /* 3-pin, 8-bit SPI master, MSB first, synchronous.
     * Choose clock polarity/phase (UCCKPH/UCCKPL) compatible with CC1101.
     * CC1101 SPI: data is sampled on the rising edge, shifted out on falling edge (CPOL=0, CPHA=0).
     * For MSP430, that corresponds to UCCKPH=0, UCCKPL=0 if using standard mode.
     */
    UCA0CTLW0 = UCSWRST | UCMST | UCSYNC | UCMSB; /* default CKPH=0, CKPL=0 */

    /* Clock source: SMCLK */
    UCA0CTLW0 |= UCSSEL__SMCLK;

    /* Set baud rate divider: SMCLK / 4 (adjust as desired) */
    UCA0BRW = 4;

    /* Release for operation */
    UCA0CTLW0 &= ~UCSWRST;
}

void cc1101_hal_init(void)
{
    /* CSn on P4.7 as GPIO output, start high (inactive) */
    P4SEL0 &= ~BIT7;
    P4SEL1 &= ~BIT7;
    CC1101_CSN_PORT_DIR |= CC1101_CSN_PIN;
    cc1101_hal_csn_high();

    /* GDO0 as input with pull-down (optional) */
    CC1101_GDO0_PORT_DIR &= ~CC1101_GDO0_PIN;
    CC1101_GDO0_PORT_REN |= CC1101_GDO0_PIN;
    CC1101_GDO0_PORT_OUT &= ~CC1101_GDO0_PIN;

    cc1101_hal_spi_init();
}

uint8_t cc1101_hal_spi_tx_rx(uint8_t data)
{
    /* Wait for TX buffer ready */
    while (!(UCA0IFG & UCTXIFG))
        ;

    UCA0TXBUF = data;

    /* Wait for RX buffer full */
    while (!(UCA0IFG & UCRXIFG))
        ;

    return UCA0RXBUF;
}
