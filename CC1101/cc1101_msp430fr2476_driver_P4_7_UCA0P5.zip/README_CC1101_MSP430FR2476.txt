CC1101 driver for MSP430FR2476 (bare-metal C, CCS-ready)
=======================================================

Folder hierarchy (recommended inside your CCS project):
-------------------------------------------------------
<YourProject>/
  cc1101/
    cc1101.h
    cc1101.c
    cc1101_regs.h
    cc1101_config.h
    cc1101_hal.h
    cc1101_hal.c

This ZIP has been tailored for:
  - MSP430FR2476
  - eUSCI_A0 SPI on P5.0 (SCLK), P5.1 (SOMI), P5.2 (SIMO)
  - CC1101 CSn on P4.7 (UCA0STE pin as GPIO)

How to integrate:
-----------------
1. In CCS, create a folder named "cc1101" in your project (right-click project -> New -> Folder).
2. Copy all files from this package into that folder.
3. Make sure your compiler include path contains the project root (default in CCS), so
   that #include "cc1101/cc1101.h" works from your application code.

4. If your wiring matches:
     - CC1101 SI   -> P5.2 (UCA0SIMO)
     - CC1101 SO   -> P5.1 (UCA0SOMI)
     - CC1101 SCLK -> P5.0 (UCA0CLK)
     - CC1101 CSn  -> P4.7 (GPIO)
     - CC1101 GDO0 -> P1.2 (GPIO input)
   then you do not need to change the HAL pin macros. Otherwise, edit cc1101_hal.h.

5. Ensure your project is targeting MSP430FR2476 and that <msp430.h> pulls in the correct
   device header.

6. In your main.c (or similar):

   #include "cc1101/cc1101.h"

   int main(void)
   {
       WDTCTL = WDTPW | WDTHOLD; // Stop watchdog

       // TODO: Configure clocks here (set up SMCLK to match SMCLK_FREQUENCY_HZ in cc1101_hal.h)

       cc1101_init();

       uint8_t tx_data[] = "Hello CC1101";
       (void)cc1101_send_packet(tx_data, sizeof(tx_data) - 1);

       while (1) {
           __no_operation();
       }
   }

7. Radio configuration:
   - The default configuration in cc1101_config.h is a generic 915 MHz, 38.4 kbps
     GFSK setup. You SHOULD regenerate the exact register settings for your
     application using TI SmartRF Studio and replace cc1101_default_settings[] with
     your exported register values.

8. Regulatory note:
   - Ensure that your chosen frequency, modulation, and output power comply with
     the applicable regulations (e.g., FCC Part 15.247/249 in the US).
