#ifndef CC1101_CONFIG_H
#define CC1101_CONFIG_H

#include <stdint.h>
#include "cc1101_regs.h"

/*
 * Example CC1101 configuration for:
 *  - 915 MHz
 *  - 38.4 kbps
 *  - GFSK
 *  - Packet mode, variable length, CRC enabled
 *
 * These values are reasonably standard but you should regenerate them with
 * SmartRF Studio for your exact requirements and regulations, then update
 * this table.
 */

typedef struct {
    uint8_t addr;
    uint8_t value;
} cc1101_reg_setting_t;

static const cc1101_reg_setting_t cc1101_default_settings[] = {
    { CC1101_IOCFG2,   0x29 }, /* GDO2: Sync word sent/received, end of packet */
    { CC1101_IOCFG0,   0x06 }, /* GDO0: Assert when sync word received, deassert end of packet */
    { CC1101_FIFOTHR,  0x47 },
    { CC1101_PKTLEN,   0x3D }, /* Max packet length 61 bytes */
    { CC1101_PKTCTRL1, 0x04 }, /* No address check */
    { CC1101_PKTCTRL0, 0x05 }, /* Variable length, CRC enabled, data whitening off */
    { CC1101_FSCTRL1,  0x06 }, /* Frequency offset (IF) */
    { CC1101_FREQ2,    0x23 }, /* 915 MHz center frequency (approx) */
    { CC1101_FREQ1,    0x31 },
    { CC1101_FREQ0,    0x3B },
    { CC1101_MDMCFG4,  0xCA }, /* 38.4 kbps, 200 kHz RX filter (approx) */
    { CC1101_MDMCFG3,  0x83 },
    { CC1101_MDMCFG2,  0x93 }, /* GFSK, 30/32 sync, Manchester off */
    { CC1101_MDMCFG1,  0x22 },
    { CC1101_MDMCFG0,  0xF8 },
    { CC1101_DEVIATN,  0x34 }, /* Deviation ~20 kHz */
    { CC1101_MCSM0,    0x18 }, /* Auto calibrate when going from IDLE to RX/TX */
    { CC1101_FOCCFG,   0x16 },
    { CC1101_BSCFG,    0x6C },
    { CC1101_AGCCTRL2, 0x43 },
    { CC1101_AGCCTRL1, 0x40 },
    { CC1101_AGCCTRL0, 0x91 },
    { CC1101_FREND1,   0x56 },
    { CC1101_FREND0,   0x10 },
    { CC1101_FSCAL3,   0xE9 },
    { CC1101_FSCAL2,   0x2A },
    { CC1101_FSCAL1,   0x00 },
    { CC1101_FSCAL0,   0x1F },
    { CC1101_TEST2,    0x81 },
    { CC1101_TEST1,    0x35 },
    { CC1101_TEST0,    0x09 }
};

#define CC1101_DEFAULT_SETTINGS_COUNT (sizeof(cc1101_default_settings)/sizeof(cc1101_default_settings[0]))

/*
 * Example PA table. You must ensure this complies with your output power
 * and regulatory requirements. The single-entry PATABLE selects one
 * output power level.
 */
static const uint8_t cc1101_default_patable[1] = {
    0xC0 /* ~10 dBm at 915 MHz for 3.0 V supply (approx, see datasheet) */
};

#endif /* CC1101_CONFIG_H */
